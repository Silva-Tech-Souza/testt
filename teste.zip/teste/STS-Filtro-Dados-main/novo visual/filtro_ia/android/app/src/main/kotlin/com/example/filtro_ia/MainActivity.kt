package com.example.filtro_ia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
