package com.example.systen_filtro_pdf_text

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
