<?php
/**
 * View for material icon
 *
 * @package    Cherry_Framework
 * @subpackage View
 * @author     Cherry Team <support@cherryframework.com>
 * @copyright  Copyright (c) 2012 - 2015, Cherry Team
 * @link       http://www.cherryframework.com/
 * @license    http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */
?>
<i class="material-icons">&#x<?php echo $__data['code']; ?>;</i>
